

#include "bsp_color_led.h"

static void SetRGBColor(uint32_t rgb);
static void SetColorValue(uint8_t r, uint8_t g, uint8_t b);
static void COLOR_TIMx_GPIO_Config(void);
static void COLOR_TIMx_Mode_Config(void);

static void COLOR_TIMx_LED_Init(void);
static void COLOR_TIMx_LED_Close(void);

static void COLOR_TIMx_GPIO_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  /* GPIO clock enable */
  RCC_APB2PeriphClockCmd(COLOR_TIM_GPIO_CLK, ENABLE);

  /*IO设置*/
  COLOR_GPIO_REMAP_FUN();

  /* 配置LED灯用到的引脚 */
  // 红
  GPIO_InitStructure.GPIO_Pin = COLOR_RED_TIM_LED_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // 复用推挽输出
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

  GPIO_Init(COLOR_RED_TIM_LED_PORT, &GPIO_InitStructure);

  // 绿
  GPIO_InitStructure.GPIO_Pin = COLOR_GREEN_TIM_LED_PIN;
  GPIO_Init(COLOR_GREEN_TIM_LED_PORT, &GPIO_InitStructure);

  // 蓝
  GPIO_InitStructure.GPIO_Pin = COLOR_BLUE_TIM_LED_PIN;
  GPIO_Init(COLOR_BLUE_TIM_LED_PORT, &GPIO_InitStructure);
}

static void COLOR_TIMx_Mode_Config(void)
{
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  TIM_OCInitTypeDef TIM_OCInitStructure;

  /* 设置TIM CLK 时钟 */
  // 使能COLOR_TIMx时钟
  COLOR_TIM_APBxClock_FUN(COLOR_TIM_CLK, ENABLE);

  /* 基本定时器配置 */
  // 当定时器从0计数到255，即为256次，为一个定时周期
  TIM_TimeBaseStructure.TIM_Period = 255;
  // 设置预分频
  TIM_TimeBaseStructure.TIM_Prescaler = 1999;
  // 设置时钟分频系数：不分频(这里用不到)
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  // 向上计数模式
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(COLOR_TIMx, &TIM_TimeBaseStructure);

  /* PWM模式配置 */
  // 配置为PWM模式1
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  // 使能输出
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  // 设置初始PWM脉冲宽度为0
  TIM_OCInitStructure.TIM_Pulse = 0;
  // 当定时器计数值小于CCR_Val时为低电平
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;

  // 使能通道和预装载
  COLOR_RED_TIM_OCxInit(COLOR_TIMx, &TIM_OCInitStructure);
  COLOR_RED_TIM_OCxPreloadConfig(COLOR_TIMx, TIM_OCPreload_Enable);

  // 使能通道和预装载
  COLOR_GREEN_TIM_OCxInit(COLOR_TIMx, &TIM_OCInitStructure);
  COLOR_GREEN_TIM_OCxPreloadConfig(COLOR_TIMx, TIM_OCPreload_Enable);

  // 使能通道和预装载
  COLOR_BLUE_TIM_OCxInit(COLOR_TIMx, &TIM_OCInitStructure);
  COLOR_BLUE_TIM_OCxPreloadConfig(COLOR_TIMx, TIM_OCPreload_Enable);

  // 使能COLOR_TIMx重载寄存器ARR
  TIM_ARRPreloadConfig(COLOR_TIMx, ENABLE);

  // 使能定时器
  TIM_Cmd(COLOR_TIMx, ENABLE);
}

static void COLOR_TIMx_LED_Init(void)
{
  COLOR_TIMx_GPIO_Config();
  COLOR_TIMx_Mode_Config();
}

static void COLOR_TIMx_LED_Close(void)
{
  SetColorValue(0, 0, 0);
  TIM_Cmd(COLOR_TIMx, DISABLE);
  COLOR_TIM_APBxClock_FUN(COLOR_TIM_CLK, DISABLE);

  GPIO_SetBits(COLOR_RED_TIM_LED_PORT, COLOR_RED_TIM_LED_PIN);
  GPIO_SetBits(COLOR_GREEN_TIM_LED_PORT, COLOR_GREEN_TIM_LED_PIN);
  GPIO_SetBits(COLOR_BLUE_TIM_LED_PORT, COLOR_BLUE_TIM_LED_PIN);
}

static void SetRGBColor(uint32_t rgb)
{
  COLOR_TIMx->COLOR_RED_CCRx = (uint8_t)(rgb >> 16);  // R
  COLOR_TIMx->COLOR_GREEN_CCRx = (uint8_t)(rgb >> 8); // G
  COLOR_TIMx->COLOR_BLUE_CCRx = (uint8_t)rgb;         // B
}

static void SetColorValue(uint8_t r, uint8_t g, uint8_t b)
{

  COLOR_TIMx->COLOR_RED_CCRx = r;
  COLOR_TIMx->COLOR_GREEN_CCRx = g;
  COLOR_TIMx->COLOR_BLUE_CCRx = b;
}

void Color_Timer_Led_Pwm_Set(uint8_t r, uint8_t g, uint8_t b, uint32_t sleep_time)
{
  COLOR_TIMx_LED_Init();
  SetColorValue(r, g, b);
  while (sleep_time--)
  {
  }
  COLOR_TIMx_LED_Close();
}
/*********************************************END OF FILE**********************/
