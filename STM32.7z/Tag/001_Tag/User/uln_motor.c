#include "uln_motor.h"

static void ULN_Mtr_Stepper_Stop(void);
static void ULN_Mtr_SingleStep_Phasecw4(uint8_t u8_step_num);
static void ULN_Mtr_SingleStep_Phasecw8(uint8_t u8_step_num);
static void ULN_Mtr_RotateByStep_Phasecw4(MtrDir dir,uint32_t u32_step_num,uint16_t u16_delay_time);
static void ULN_Mtr_RotateByStep_Phasecw8(MtrDir dir,uint32_t u32_step_num,uint16_t u16_delay_time);
static uint8_t u8_Mtr_Step=0;

static void ULN_Mtr_Stepper_Stop(void)
{
	
	  GPIO_ResetBits(MTR_GPIO_PORT,LIN1_GPIO_PIN | LIN2_GPIO_PIN | LIN3_GPIO_PIN | LIN4_GPIO_PIN);
//		GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN | LIN3_GPIO_PIN | LIN4_GPIO_PIN | LIN1_GPIO_PIN,Bit_RESET);
}

void ULN_Mtr_Stepper_GPIO_Configured_Init(void)
{
	  GPIO_InitTypeDef GPIO_InitStructure;

		RCC_APB2PeriphClockCmd( MTR_GPIO_CLK, ENABLE);
		GPIO_InitStructure.GPIO_Pin = LIN1_GPIO_PIN | LIN2_GPIO_PIN | LIN3_GPIO_PIN | LIN4_GPIO_PIN;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
		GPIO_Init(MTR_GPIO_PORT, &GPIO_InitStructure);	
	
		ULN_Mtr_Stepper_Stop();

}






static void ULN_Mtr_SingleStep_Phasecw4(uint8_t u8_step_num)
{
	uint16_t u16_i=0;
	switch(u8_step_num)
	{
		case 0:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN3_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 1:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN|LIN3_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 2:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN3_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN1_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 3:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN4_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN3_GPIO_PIN|LIN1_GPIO_PIN,Bit_RESET);
		break;
		default:
			break;
	
	
	}
	for(u16_i=0;u16_i < PHASECW_Delay_Time;u16_i++)
	{
	
	}
	ULN_Mtr_Stepper_Stop();

}
static void ULN_Mtr_SingleStep_Phasecw8(uint8_t u8_step_num)
{
	uint16_t u16_i=0;
	switch(u8_step_num)
	{
		case 0:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN3_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 1:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN|LIN2_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN3_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 2:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN|LIN3_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 3:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN3_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 4:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN3_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN1_GPIO_PIN|LIN4_GPIO_PIN,Bit_RESET);
		break;
		case 5:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN3_GPIO_PIN|LIN4_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN1_GPIO_PIN|LIN2_GPIO_PIN,Bit_RESET);
		break;
		case 6:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN4_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN1_GPIO_PIN|LIN3_GPIO_PIN,Bit_RESET);
		break;
		case 7:
			GPIO_WriteBit(MTR_GPIO_PORT,LIN4_GPIO_PIN|LIN1_GPIO_PIN,Bit_SET);
			GPIO_WriteBit(MTR_GPIO_PORT,LIN2_GPIO_PIN|LIN3_GPIO_PIN,Bit_RESET);
		break;
		default:
			break;
	
	
	}
	for(u16_i=0;u16_i < PHASECW_Delay_Time;u16_i++)
	{
	
	}
	ULN_Mtr_Stepper_Stop();

}


static void ULN_Mtr_RotateByStep_Phasecw4(MtrDir dir,uint32_t u32_step_num,uint16_t u16_delay_time)
{
	uint16_t u16_i=0;
	while(u32_step_num--)
	{
		if(ForWard == dir)
		{
				u8_Mtr_Step++;
				if(u8_Mtr_Step > 3)
				{
				
						u8_Mtr_Step = 0;
				}
		
		}
		else
		{
				if(u8_Mtr_Step == 0)
				{
				
						u8_Mtr_Step = 4;
				}
				u8_Mtr_Step--;
		}
		for(u16_i=0;u16_i < u16_delay_time;u16_i++)
		{
		
		}
		ULN_Mtr_SingleStep_Phasecw4(u8_Mtr_Step);
	}

}
static void ULN_Mtr_RotateByStep_Phasecw8(MtrDir dir,uint32_t u32_step_num,uint16_t u16_delay_time)
{
	uint16_t u16_i=0;
	while(u32_step_num--)
	{
		if(ForWard == dir)
		{
				u8_Mtr_Step++;
				if(u8_Mtr_Step > 7)
				{
				
						u8_Mtr_Step = 0;
				}
		
		}
		else
		{
				if(u8_Mtr_Step == 0)
				{
				
						u8_Mtr_Step = 8;
				}
				u8_Mtr_Step--;
		}
		for(u16_i=0;u16_i < u16_delay_time;u16_i++)
		{
		
		}
		ULN_Mtr_SingleStep_Phasecw8(u8_Mtr_Step);
	}

}

void ULN_Mtr_RotateByLoop_Phasecw4(MtrDir dir,uint32_t loop,uint16_t u16_delay_time)
{

	ULN_Mtr_RotateByStep_Phasecw4( dir, loop*PHASECW_4, u16_delay_time);

}

void ULN_Mtr_RotateByLoop_Phasecw8(MtrDir dir,uint32_t loop,uint16_t u16_delay_time)
{

	ULN_Mtr_RotateByStep_Phasecw8( dir, loop*PHASECW_8, u16_delay_time);

}


/* Advance Timer  */
static void ADVANCE_TIM_GPIO_Config(void);
static void ADVANCE_TIM_Mode_Config(void);
static void ADVANCE_TIM_ULN_Step(uint8_t u8_chnl, uint8_t u8_cnt_value);
static void ADVANCE_TIM_ULN_RotateByStep(MtrDir dir, uint32_t u32_step_num, uint16_t u16_delay_time);

static void ADVANCE_TIM_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

	// CH1~4 输出比较通道 GPIO 初始化
    RCC_APB2PeriphClockCmd(ADVANCE_TIM_CHx_GPIO_CLK, ENABLE);
	GPIO_InitStructure.GPIO_Pin = ADVANCE_CH1_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(ADVANCE_TIM_CHx_PORT, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = ADVANCE_CH2_GPIO_PIN;
	GPIO_Init(ADVANCE_TIM_CHx_PORT, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = ADVANCE_CH3_GPIO_PIN;
	GPIO_Init(ADVANCE_TIM_CHx_PORT, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin =  ADVANCE_CH4_GPIO_PIN;
	GPIO_Init(ADVANCE_TIM_CHx_PORT, &GPIO_InitStructure);

}
static void ADVANCE_TIM_Mode_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_BDTRInitTypeDef TIM_BDTRInitStructure;
	
    // 开启定时器时钟,即内部时钟CK_INT=72M
    ADVANCE_TIM_APBxClock_FUN(ADVANCE_TIM_CLK,ENABLE);

    /*--------------------时基结构体初始化-------------------------*/
    
    // 自动重装载寄存器的值，累计TIM_Period+1个频率后产生一个更新或者中断
    TIM_TimeBaseStructure.TIM_Period=ADVANCE_TIM_PERIOD;
    // 驱动CNT计数器的时钟 = Fck_int/(psc+1)
    TIM_TimeBaseStructure.TIM_Prescaler= ADVANCE_TIM_PSC;
    // 时钟分频因子 ，配置死区时间时需要用到
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;
    // 计数器计数模式，设置为向上计数
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;
    // 重复计数器的值，没用到不用管
    TIM_TimeBaseStructure.TIM_RepetitionCounter=0;
    // 初始化定时器
    TIM_TimeBaseInit(ADVANCE_TIM, &TIM_TimeBaseStructure);

    /*--------------------输出比较结构体初始化-------------------*/
    
    // 配置为PWM模式1
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    // 输出使能
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    // 互补输出使能
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
    // 设置占空比大小
    TIM_OCInitStructure.TIM_Pulse = 0;
    // 输出通道电平极性配置
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;

	CH1_TIM_OCxInit(ADVANCE_TIM, &TIM_OCInitStructure);
    CH1_TIM_OCxPreloadConfig(ADVANCE_TIM, TIM_OCPreload_Enable);

	CH2_TIM_OCxInit(ADVANCE_TIM, &TIM_OCInitStructure);
    CH2_TIM_OCxPreloadConfig(ADVANCE_TIM, TIM_OCPreload_Enable);

	CH3_TIM_OCxInit(ADVANCE_TIM, &TIM_OCInitStructure);
    CH3_TIM_OCxPreloadConfig(ADVANCE_TIM, TIM_OCPreload_Enable);

	CH4_TIM_OCxInit(ADVANCE_TIM, &TIM_OCInitStructure);
    CH4_TIM_OCxPreloadConfig(ADVANCE_TIM, TIM_OCPreload_Enable);
    
	TIM_ARRPreloadConfig(ADVANCE_TIM, ENABLE);

    //使能定时器
    TIM_Cmd(ADVANCE_TIM, ENABLE);
    
}

static void ADVANCE_TIM_ULN_Step(uint8_t u8_chnl,uint8_t u8_cnt_value)
{
	uint16_t u16_i = 0;


	switch (u8_chnl)
	{
	case 0:
		ADVANCE_TIM->ADVANCE_CH1_CCR = 0;
		ADVANCE_TIM->ADVANCE_CH2_CCR = 0;
		ADVANCE_TIM->ADVANCE_CH3_CCR = 0;
		ADVANCE_TIM->ADVANCE_CH4_CCR = 200;
		break;
	
	default:
		break;
	}
	// switch(u8_chnl)
    // {
    //     case 0: // LIN1
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=NU_8;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=NU_8-u8_cnt_value;
    //     break;
    //     case 1: // LIN1 LIN2 
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=NU_8;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=u8_cnt_value;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=0;
    //     break;
    //     case 2: // LIN2 
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=NU_8-u8_cnt_value;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=NU_8;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=0;
    //     break;
    //     case 3: // LIN2 LIN3 
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=NU_8;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=u8_cnt_value;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=0;
    //     break;
    //     case 4: // LIN3
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=NU_8-u8_cnt_value;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=NU_8;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=0;
    //     break;
    //     case 5: // LIN3 LIN4
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=NU_8;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=u8_cnt_value;
    //     break;
    //     case 6: // LIN4
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=NU_8-u8_cnt_value;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=NU_8;
    //     break;
    //     case 7: // LIN4 LIN1
    //         ADVANCE_TIM->ADVANCE_CH1_CCR=u8_cnt_value;
    //         ADVANCE_TIM->ADVANCE_CH2_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH3_CCR=0;
    //         ADVANCE_TIM->ADVANCE_CH4_CCR=NU_8;
    //     break;
    //     default:
    //     break;
    // }

    
	
	for (u16_i = 0; u16_i < PHASECW_Delay_Time;u16_i++)
	{

	}
	ADVANCE_TIM->ADVANCE_CH1_CCR=0;
	ADVANCE_TIM->ADVANCE_CH2_CCR=0;
	ADVANCE_TIM->ADVANCE_CH3_CCR=0;
	ADVANCE_TIM->ADVANCE_CH4_CCR=0;
	ULN_Mtr_Stepper_Stop();

}


static void ADVANCE_TIM_ULN_RotateByStep(MtrDir dir,uint32_t u32_step_num,uint16_t u16_delay_time)
{
	uint16_t u16_i = 0;
	uint8_t u8_chnl = 0, u8_cnt_value = 0;
	uint8_t u8_i = 0, u8_j = 0;
	while(u32_step_num--)
	{
		if(ForWard == dir)
		{
			ADVANCE_TIM_ULN_Step(u8_i, u8_j);
				
		}
		else
		{
			// u8_i = LIN_PHAS_BEAT;
			// while(u8_i)
			// {
			// 	u8_i--;
			// 	u8_j = NU_8;
			// 	while(u8_j)
			// 	{
			// 		u8_j--;
			// 		ADVANCE_TIM_ULN_Step(u8_i,u8_j);
			// 	}
				
			// }
		}
		for (u16_i = 0; u16_i < 4;u16_i++)
		{

		}
	}
	
}
void ADVANCE_TIM_ULN_Configured_Init(void)
{
	ADVANCE_TIM_GPIO_Config();
	ADVANCE_TIM_Mode_Config();
}
void ADVANCE_TIM_ULN_RotateByLoop(MtrDir dir,uint16_t u16_delay_time)
{
	
	ADVANCE_TIM_ULN_RotateByStep(dir, PHASECW_8, u16_delay_time);
}