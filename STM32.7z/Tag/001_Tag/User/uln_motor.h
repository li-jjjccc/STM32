#ifndef __ULN_MOTOR_H
#define __ULN_MOTOR_H

#include "misc.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_tim.h"


typedef enum{
	ForWard = 0,
	Reversal = 1
}MtrDir;

#define NU_8						    255
#define LIN_PHAS_BEAT   				8
#define MTR_GPIO_PORT 		   			GPIOC			              /* GPIO�˿� */
#define MTR_GPIO_CLK 	 		    	RCC_APB2Periph_GPIOC		/* GPIO�˿�ʱ�� */
#define LIN1_GPIO_PIN					GPIO_Pin_6	
#define LIN2_GPIO_PIN					GPIO_Pin_7
#define LIN3_GPIO_PIN					GPIO_Pin_8	
#define LIN4_GPIO_PIN					GPIO_Pin_9

#define PHASECW_4		2048
#define PHASECW_8		4096
#define PHASECW_Delay_Time	500
void ULN_Mtr_Stepper_GPIO_Configured_Init(void);
void ULN_Mtr_RotateByLoop_Phasecw4(MtrDir dir,uint32_t loop,uint16_t u16_delay_time);
void ULN_Mtr_RotateByLoop_Phasecw8(MtrDir dir,uint32_t loop,uint16_t u16_delay_time);




#define            ADVANCE_TIM                   TIM8
#define            ADVANCE_TIM_APBxClock_FUN     RCC_APB2PeriphClockCmd
#define            ADVANCE_TIM_CLK               RCC_APB2Periph_TIM8
#define            ADVANCE_TIM_PERIOD            255
#define            ADVANCE_TIM_PSC               1999
#define            ADVANCE_TIM_PULSE             4
#define            ADVANCE_TIM_IRQ               TIM8_UP_IRQn
#define            ADVANCE_TIM_IRQHandler        TIM8_UP_IRQHandler

// TIM8 CH1~CH4
#define            ADVANCE_TIM_CHx_GPIO_CLK      RCC_APB2Periph_GPIOC
#define            ADVANCE_TIM_CHx_PORT          GPIOC
#define			   ADVANCE_CH1_GPIO_PIN			 GPIO_Pin_6
#define			   ADVANCE_CH2_GPIO_PIN			 GPIO_Pin_7
#define			   ADVANCE_CH3_GPIO_PIN			 GPIO_Pin_8	
#define 		   ADVANCE_CH4_GPIO_PIN			 GPIO_Pin_9

#define 		   CH1_TIM_OCxInit               TIM_OC1Init
#define 		   CH2_TIM_OCxInit               TIM_OC2Init
#define 		   CH3_TIM_OCxInit               TIM_OC3Init
#define 		   CH4_TIM_OCxInit               TIM_OC4Init

#define  		   CH1_TIM_OCxPreloadConfig      TIM_OC1PreloadConfig
#define  		   CH2_TIM_OCxPreloadConfig      TIM_OC2PreloadConfig
#define  		   CH3_TIM_OCxPreloadConfig      TIM_OC3PreloadConfig
#define  		   CH4_TIM_OCxPreloadConfig      TIM_OC4PreloadConfig

#define 		   ADVANCE_CH1_CCR			     CCR1
#define 		   ADVANCE_CH2_CCR			     CCR2
#define 		   ADVANCE_CH3_CCR			     CCR3
#define 		   ADVANCE_CH4_CCR			     CCR4

// TIM8 CH1N BKIN
// #define            ADVANCE_TIM_CH1N_BKIN_GPIO_CLK    RCC_APB2Periph_GPIOA
// #define            ADVANCE_TIM_CH1N_BKIN_PORT        GPIOA
// #define			   ADVANCE_CH1N_GPIO_PIN		     GPIO_Pin_7
// #define			   ADVANCE_BKIN_GPIO_PIN		     GPIO_Pin_6

// #define            ADVANCE_TIM_CH2_3N_GPIO_CLK       RCC_APB2Periph_GPIOB
// #define            ADVANCE_TIM_CH2_3N_PORT      	 GPIOB
// #define			   ADVANCE_CH2N_GPIO_PIN			 GPIO_Pin_0
// #define			   ADVANCE_CH3N_GPIO_PIN			 GPIO_Pin_1

void ADVANCE_TIM_ULN_Configured_Init(void);
void ADVANCE_TIM_ULN_RotateByLoop(MtrDir dir, uint16_t u16_delay_time);
#endif /* __ULN_MOTOR_H */