#include "h.h"
volatile uint32_t time = 0;
__IO uint32_t rgb_color = 0xFFFFFF;

extern uint8_t u8_Usart_DMA_Buff_Rx[SENDBUFF_SIZE];

void sleep(uint16_t u16_time)
{
	uint16_t cnt = 0;
	for (cnt = 0; cnt < u16_time; cnt++)
	{
	}
}

void System_Clock_Configured()
{

	HSE_SetSysClock(SYSTEM_CLOCK_72MHZ);
	MCO_GPIO_Config();
	RCC_MCOConfig(RCC_MCO_SYSCLK);
}
int main()
{
	uint16_t u16_cnt;
//	uint8_t u8_led_index = 0;
//	char c_user_input = '\0';

//	uint16_t u16_cnt = 0;
//	uint8_t u8_cnt = 0;
//	
//	uint16_t i;

	//  Beep
//	BEEP_GPIO_Config();
	//	BEEP(OFF);
	//	BEEP(ON);

	//  LED
//	LED_GPIO_Config();
	//  LED_RGBOFF;
	//	LED_RED;

	// Key1 Key2
	//	Key_GPIO_Config();
	//	if( KEY_ON == KEY1_SCAN())
	//	if( KEY_ON == KEY2_SCAN())

	// Syetem Clock Configured
//	HSE_SetSysClock(RCC_PLLMul_9);

	// EXTI with KEY
//	EXTI_Key_Config();

	// System Tick
//	SysTick_Init();

	// Usart Communication
//	USART_Config();
//	Usart_SendString(DEBUG_USARTx, "Hi\n");
//	printf("STM32\n\n\n");
//	for (u8_led_index = 0; u8_led_index < LIGHT_NUM; u8_led_index++)
//	{
//		printf("%s\n", LED_Light_Control(u8_led_index));
//		SysTick_Delay_Ms(100);
//	}

//	while (c_user_input != 'c')
//	{
//		c_user_input = getchar();
//		if ((uint8_t)c_user_input >= (uint8_t)('0') && (uint8_t)c_user_input < (uint8_t)('8'))
//		{
//			printf("%s\n", LED_Light_Control(((uint8_t)c_user_input - (uint8_t)('0'))));
//		}
//	}

	// DMA Configured
//	USARTx_DMA_Config();
//	USARTx_DMA_TX();
//	SysTick_Delay_Ms(1000);

//	USARRx_DMA_Config();
//	USARTx_DMA_RX();
//	SysTick_Delay_Ms(100);
//	for (u16_cnt = 0; u16_cnt < SENDBUFF_SIZE; u16_cnt++)
//	{
//		printf("Tx: %d\n", u8_Usart_DMA_Buff_Rx[u16_cnt]);
//	}

	// IIC
	// Todo IIC Read Write Test Error
//	printf("IIC_Test : %d\r\n",ee_Test());

	// SPI
//	printf("SPI_Fash_Test : %d\r\n",SPI_Fash_Test());
	// LCD
//	ILI9341_Init(); 
//	USART_Config();
//	ILI9341_GramScan(6);
	
	

//	while(1)
//	{
//		LCD_SetFont(&Font8x16);
//		LCD_SetColors(GREEN, RED);
//		ILI9341_Clear(0, 0, LCD_X_LENGTH, LCD_Y_LENGTH);
//		ILI9341_DispStringLine_EN(LINE(0), "BH 3.2 inch LCD para:");
//		ILI9341_DispStringLine_EN(LINE(1), "Image resolution:240x320 px");
//		ILI9341_DispStringLine_EN(LINE(2), "ILI9341 LCD driver");
//		ILI9341_DispStringLine_EN(LINE(3), "XPT2046 Touch Pad driver");
//	}
	

	// basic Timer
//	BASIC_TIM_Init();

	// pwm led
//	Color_Timer_Led_Pwm_Set(60, 60, 60, 10000);
	// breathing led
//	TIMx_Breathing_Init();



	// ULN_Mtr_Stepper_GPIO_Configured_Init();
	// while(1)
	// {
	// 		ULN_Mtr_RotateByLoop_Phasecw8(1,2,3);
	// }

	ADVANCE_TIM_ULN_Configured_Init();
	while(1)
	{
		ADVANCE_TIM_ULN_RotateByLoop(0, 1);
	}
	
}

void SystemInit()
{
}
