#include<reg51.h>
#include "servo.h"



void main ( void )	 //主函数
{
  InitialTimer();
	for(;;)
	{
		ControlLeftOrRight();
	}
}

void Timer1 ( void ) interrupt 3  //定时器中断函数
{
  TH1 = ( 65535 - 500 ) / 256;
	TL1 = ( 65535 - 500 ) % 256;
	TimeOutCounter ++;

	switch ( LeftOrRight )
	{
		case 0 :	  //为0时，舵机归位，脉宽1.5ms
		{
			if( TimeOutCounter <= 3 )
			{
				ControlPort = 1;
			}
			else 
			{
				ControlPort = 0;
			}
			break;
		}
		case 1 :     //为1时，舵机左转，脉宽1ms（理论值），实际可以调试得出
		{
			if( TimeOutCounter <= 1 )
			{
				ControlPort = 1;
			}
			else 
			{
				ControlPort = 0;
			}
			break;
		}
		case 2 :   //为2时，舵机右转，脉宽2ms（理论值），实际可以调试得出
		{
			if( TimeOutCounter <= 6 )
			{
				ControlPort = 1;
			}
			else 
			{
				ControlPort = 0;
			}
			break;
		}
		default : break;
	}
	
	if( TimeOutCounter == 80 )	 //周期20ms（理论值），比较可靠，最好不要修改
	{
		TimeOutCounter = 0;
	}
}
