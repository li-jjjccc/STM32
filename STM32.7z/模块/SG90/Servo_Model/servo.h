#ifndef __SERVO_H_
#define __SERVO_H_

#include <reg51.h> 
#include "intrins.h"

#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint
#define uint unsigned int
#endif


#define Stop 0    //宏定义，停止
#define Left 1	  //宏定义，左转
#define Right 2	  //宏定义，右转


/*以下定义输出管脚*/ 
sbit ControlPort = P2^0;  //舵机信号端口
sbit KeyLeft = P1^0;	  //左转按键端口
sbit KeyRight = P1^1;	  //右转按键端口
sbit KeyStop = P1^2;	  //归位按键端口

uchar TimeOutCounter = 0; //TimeOutCounter：定时器溢出计数
uchar LeftOrRight = 0;  //  LeftOrRight：舵机左右旋转标志 


void InitialTimer ( void )  //配置定时器1
{
	{
    TMOD=0x10;   //定时/计数器1工作于方式1
    TH1 = ( 65535 - 500 ) / 256;	  //0.25ms
	  TL1 = ( 65535 - 500 ) % 256;
    EA=1;        //开总中断
    ET1=1;       //允许定时/计数器1 中断
    TR1=1;       //启动定时/计数器1 中断
}
}
void ControlLeftOrRight ( void )   //控制舵机函数
{
	if( KeyStop == 0 )
	{
		//while ( !KeyStop );	   //使标志等于Stop（0），在中断函数中将用到
		LeftOrRight = Stop;
	}

	if( KeyLeft == 0 )
	{
		//while ( !KeyLeft );	   //使标志等于Left（1），在中断函数中将用到
		LeftOrRight = Left;
	}

	if( KeyRight == 0 )
	{
		//while ( !KeyRight );   //使标志等于Right（2），在中断函数中将用到
		LeftOrRight = Right;
	}

}

#endif