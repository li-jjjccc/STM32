#include "sys.h"
#include "usart.h"
#include "delay.h"
#include "timer.h"
#include "key.h"
#include "oled.h"
unsigned int key=0,actual_pwm=100;
u32 part=0,time=0;
/**
  *����:�����ת
  *expect_pwm:���Ŀ����תֵ
  *s:�������ָ��λ�ú�ʱ
  *��Сת���Ƕȣ�0.45*5
  */
void SG90(u32 expect_pwm,u32 s)
{
    if(expect_pwm>actual_pwm)
        time=1000000*s*5/(expect_pwm-actual_pwm);//΢�뼶���
    if(expect_pwm<actual_pwm)
        time=1000000*s*5/(actual_pwm-expect_pwm);//΢�뼶���
    if(expect_pwm!=actual_pwm)
    {
        if(expect_pwm>actual_pwm)
        {
            while(1)
            {
                actual_pwm=actual_pwm+5;//һ��
                TIM_SetCompare1(TIM14,actual_pwm);
                part++;
                delay_us(time);
                if(expect_pwm==actual_pwm)
                {
                    part=0;
                    break;
                }
            }
        }
        if(expect_pwm<actual_pwm)
        {
            while(1)
            {
                actual_pwm=actual_pwm-5;
                TIM_SetCompare1(TIM14,actual_pwm);
                part++;
                delay_us(time);
                if(expect_pwm==actual_pwm)
                {
                    part=0;
                    break;
                }
            }
        }
    }
}

int main(void)
{ 

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  //��ʼ����ʱ����
 	TIM14_PWM_Init(4000-1,420-1);	//84M/4200=200khz�ļ���Ƶ��,��װ��ֵ4000������PWM����Ϊ0.02s(20ms)
    KEY_Init();
   while(1) 
	{
        key=KEY_Scan(0);
        if(key==1)
        {
            SG90(500,1);
        }
        if(key==2) 
        {
            SG90(100,1);
        }
	}
}


